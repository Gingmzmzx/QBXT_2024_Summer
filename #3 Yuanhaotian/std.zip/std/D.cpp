#include<bits/stdc++.h>
#define LL long long
#define pb push_back
#define mp make_pair
#define pii pair<int,int>
using namespace std;
namespace IO
{
    const int sz=1<<15;
    char inbuf[sz],outbuf[sz];
    char *pinbuf=inbuf+sz;
    char *poutbuf=outbuf;
    inline char _getchar()
    {
        if (pinbuf==inbuf+sz)fread(inbuf,1,sz,stdin),pinbuf=inbuf;
        return *(pinbuf++);
    }
    inline void _putchar(char x)
    {
        if (poutbuf==outbuf+sz)fwrite(outbuf,1,sz,stdout),poutbuf=outbuf;
        *(poutbuf++)=x;
    }
    inline void flush()
    {
        if (poutbuf!=outbuf)fwrite(outbuf,1,poutbuf-outbuf,stdout),poutbuf=outbuf;
    }
}
inline int read(){
	int v=0,f=1;
	char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-1;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		v=v*10+c-'0';
		c=getchar();
	}
	return v*f;
}
const int Maxn=1000005;
int n,P[4];
int eu[Maxn],ev[Maxn],st[Maxn],ed[Maxn],ks,O[Maxn];
vector<int> G[Maxn],Son[Maxn];
int tree[Maxn*30],lson[Maxn*30],rson[Maxn*30],kp,rt[Maxn],siz[Maxn];
void dfs(int x,int p){
	st[x]=++ks;O[ks]=x;
	siz[x]=1;
	for (auto v:G[x]){
		if (v!=p){
			Son[x].pb(v);
			dfs(v,x);
			siz[x]+=siz[v];
		}
	}
	ed[x]=ks;
}
int build(int l,int r){
	int np=++kp;
	if (l==r){
		return np;
	}
	int mid=l+r>>1;
	lson[np]=build(l,mid);
	rson[np]=build(mid+1,r);
	return np;
}
int modify(int p,int l,int r,int pos){
	int np=++kp;
	if (l==r){
		tree[np]=tree[p]+1;
		return np;
	}
	int mid=l+r>>1;
	if (pos<=mid){
		lson[np]=modify(lson[p],l,mid,pos);
		rson[np]=rson[p];
	}
	else{
		lson[np]=lson[p];
		rson[np]=modify(rson[p],mid+1,r,pos);
	}
	tree[np]=tree[lson[np]]+tree[rson[np]];
	return np;
}
int query(int p,int l,int r,int lo,int hi){
	if (lo<=l && r<=hi){
		return tree[p]; 
	}
	int mid=l+r>>1;
	int ans=0;
	if (lo<=mid){
		ans+=query(lson[p],l,mid,lo,hi);
	}
	if (hi>mid){
		ans+=query(rson[p],mid+1,r,lo,hi);
	}
	return ans;
}
int main(){
	scanf("%d",&n);
	for (int i=1;i<=3;i++) scanf("%d",&P[i]);
	if (P[1]>P[3]) swap(P[1],P[3]);
	
	for (int i=0;i<n-1;i++){
		scanf("%d %d",&eu[i],&ev[i]);
	}
	
	if (P[2]==1){
		for (int i=1;i<=3;i++) P[i]=4-P[i];
		for (int i=0;i<n-1;i++){
			eu[i]=n+1-eu[i];
			ev[i]=n+1-ev[i];
		}
	}
	
	for (int i=0;i<n-1;i++){
		G[eu[i]].pb(ev[i]);
		G[ev[i]].pb(eu[i]);
	}
	
	dfs(1,-1);
	rt[0]=build(1,n);
	for (int i=1;i<=n;i++){
		rt[i]=modify(rt[i-1],1,n,O[i]);
	}
	LL ans=0;
	
	for (int i=1;i<=n;i++){
		vector<pair<int,int> > V; 
		int tot=0;
		for (int j=0;j<Son[i].size();j++){
			int v=Son[i][j];
			
			int t=query(rt[ed[v]],1,n,1,i)-query(rt[st[v]-1],1,n,1,i);
			
			tot+=t;
			V.pb(mp(t,siz[v]-t));
		}
		
		if (i!=1){
			V.pb(mp(i-1-tot,n-siz[i]-(i-1-tot)));
		}
		
		if (P[2]==3){
			ans+=1ll*(i-1)*(i-2)/2;
			for (int j=0;j<V.size();j++){
				ans-=1ll*(V[j].first)*(V[j].first-1)/2;
			}
		}
		else{
			for (int j=0;j<V.size();j++){
				ans+=1ll*V[j].first*(n-i-V[j].second);
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
} 
/*
5
3 2 1
1 4
4 5
2 4
4 3
*/
