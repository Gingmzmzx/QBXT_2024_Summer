#include <bits/stdc++.h>
using namespace std;
using ll = long long;

template<class T>
constexpr T power(T a, ll n) {
    T res = 1;
    for (; n; a *= a, n >>= 1) {
        if (n & 1) res *= a;
    }
    return res;
}
int h = power(3, 12);
vector<vector<int>> g(h + h);
void mian() {
    //freopen("number.in","r",stdin);
    //freopen("number.out","w",stdout);
    int n;
    cin >> n;
    cerr<<n<<endl;
    vector<int> a(n);
    for (auto &e: a) cin >> e;

    for (int i = 0; i < n+h; i++) g[i].clear();

    for (int i = 0; i < n; i++) {
        g[a[i]].push_back(h+i);
        g[h+i].push_back(a[i]);
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0, e = a[i]; e; e /= 3, j++) {
            g[h+i].push_back(a[i] - (e%3) * power(3, j));
        }
    }

    for (int s = 0; s < h; s++) {
        for (int j = 0, e = s; j < 12; e /= 3, j++) {
            int d = e % 3;
            if (d < 1) g[s].push_back(s + 2 * power(3, j));
            if (d < 2) g[s].push_back(s + power(3, j));
        }
    }

    queue<int> q;
    vector<bool> vis(n+h, false);
    q.push(h+0);
    vis[h+0] = true;
    while (q.size()) {
        int u = q.front(); q.pop();
        if (u == h+n-1) {
            cout << "yes\n";
            return;
        }
        for (auto v: g[u]) {
            if (vis[v]) continue;
            q.push(v);
            vis[v] = true;
        }
    }
    cout << "no\n";

    return;
}

int main(){
    int T;
    cin >> T;
    while (T--) {
        mian();
    }
}