#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void gi(int &x){char ch = getchar(); x = 0; while (ch < '0' || ch > '9') ch = getchar(); while (ch >= '0' && ch <= '9') x = x * 10 + ch - 48, ch = getchar();}
void pi(ll x){if (x > 9) pi(x / 10); putchar(x % 10 + 48);}

class Event {
    public:
    int x, y, tag;
    Event(){x = y = tag = 0;}
    Event(int X, int Y){x = X; y = Y; tag = 0;}
    Event(int X, int Y, int T){x = X; y = Y; tag = T;}
} E[233333];
bool operator < (const Event &a, const Event &b) {if (a.x == b.x) return a.tag < b.tag; return a.x < b.x;}
int M, B[233333], tmp[233333], ANS[233333];
void add(int x){for (; x <= M; x += x & -x) B[x]++;}
int sum(int x){int s = 0; for (; x; x -= x & -x) s += B[x]; return s;}

void clr_ds(){for (int i = 1; i <= M; i++) B[i] = 0; M = 0;}
void add_pt(int x, int y){E[++M] = Event(x, y);}
void add_qr(int x, int y, int r){E[++M] = Event(x, y, r);}
void solve(){
    int i, j, a;
    sort(E + 1, E + M + 1);
    for (i = 1; i <= M; i++) tmp[i] = E[i].y;
    sort(tmp + 1, tmp + M + 1);
    for (i = 1; i <= M; i++) {
        for (a = 262144, j = 0; a; a >>= 1)
            if (a + j <= M && tmp[a + j] <= E[i].y) j += a;
        E[i].y = j;
    }
    for (i = 1; i <= M; i++) if (E[i].tag == 0) add(E[i].y); else ANS[E[i].tag] = sum(E[i].y);
}

int w[4][222222], d[4][222222];
void dfor(int s, int m, int *d){
    d[s] = 0;
    for (int i = s + 1; i <= m; i++) {
        d[i] = 1000000000;
        for (int j = 1; j <= 3; j++)
            if (i - j >= s) d[i] = min(d[i], d[i - j] + w[j][i - j]);
    }
}
void dbac(int s, int m, int *d){
    d[s] = 0;
    for (int i = s - 1; i >= m; i--) {
        d[i] = 1000000000;
        for (int j = 1; j <= 3; j++)
            if (i + j <= s) d[i] = min(d[i], d[i + j] + w[j][i]);
    }
}

ll ans;
int n;
int cnt[233333];
#define FORL for (i = l; i < m; i++)
#define FORR for (i = r; i > m; i--)

void dac(int l, int r){
    if (r - l < 3) {
        for (int i = l; i < r; i++) {dfor(i, r, d[0]); for (int j = i + 1; j <= r; j++) ans += d[0][j];}
        return;
    }
    int m = (l + r) >> 1, i;
    dac(l, m - 2); dac(m + 2, r);
    dfor(m - 1, r, d[0]); dfor(m, r, d[1]); dfor(m + 1, r, d[2]);
    dbac(m - 1, l, d[0]); dbac(m, l, d[1]); dbac(m + 1, l, d[2]);
    FORL ans += d[0][i]; FORR ans += d[2][i];
    for (i = l; i <= r; i++) ans += d[1][i];

    FORL cnt[i] = r - m; clr_ds();
    FORR add_pt(d[0][i] - d[1][i], d[0][i] - d[2][i]);
    FORL add_qr(d[1][i] - d[0][i], d[2][i] - d[0][i], i); solve();
    FORL {ans += 1ll * ANS[i] * d[0][i]; cnt[i] -= ANS[i];} clr_ds();
    FORR add_pt(d[1][i] - d[0][i] + 1, d[1][i] - d[2][i]);
    FORL add_qr(d[0][i] - d[1][i], d[2][i] - d[1][i], i); solve();
    FORL {ans += 1ll * ANS[i] * d[1][i]; ans += 1ll * (cnt[i] - ANS[i]) * d[2][i];}

    FORR cnt[i] = m - l; clr_ds();
    FORL add_pt(d[0][i] - d[1][i], d[0][i] - d[2][i]);
    FORR add_qr(d[1][i] - d[0][i], d[2][i] - d[0][i], i); solve();
    FORR {ans += 1ll * ANS[i] * d[0][i]; cnt[i] -= ANS[i];} clr_ds();
    FORL add_pt(d[1][i] - d[0][i] + 1, d[1][i] - d[2][i]);
    FORR add_qr(d[0][i] - d[1][i], d[2][i] - d[1][i], i); solve();
    FORR {ans += 1ll * ANS[i] * d[1][i]; ans += 1ll * (cnt[i] - ANS[i]) * d[2][i];}
}

void doit(){
    ans = 0;
    gi(n);
    for (int j = 1; j <= 3; j++)
    for (int i = 1; i + j <= n; i++) gi(w[j][i]);
    dac(1, n); pi(ans); putchar('\n');
}

int main(){int T; gi(T); while (T--) doit(); return 0;}
