#define rep(i,n) for(int i=0;i<(int)(n);i++)
#define LL long long
#include<bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		vector<LL> L(n);
		rep(i,n) cin>>L[i];
		sort(L.begin(),L.end());
		bool b=false;
		LL ma=-1;
		for(int i=n-1;i>=2;i--){
			if(L[i]<L[i-1]+L[i-2]){
				LL sum=L[i]+L[i-1]+L[i-2];
				ma=max(ma,sum*(sum-2*L[i])*(sum-2*L[i-1])*(sum-2*L[i-2])/16);
			}
		}
		if(ma==-1) cout<<-1<<'\n';
		else cout<<ma<<'\n';
	}

	return 0;
}